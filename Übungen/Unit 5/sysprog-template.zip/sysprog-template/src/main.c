#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
#include <config.h>

int main(int argc, char *argv[]) {
  return EXIT_SUCCESS;
}
