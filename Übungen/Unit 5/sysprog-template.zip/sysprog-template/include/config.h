#ifndef _CONFIG_H
#define _CONFIG_H

#define CONFIG_FILE_NAME  "template.cfg"

#endif // _CONFIG_H


