//----------------------------------------------------------------
// Die Funktion qsort() ist in der Standardlibrary vorhanden,
// um Arrays oder Speicherbereiche zu sortieren.
// Schlagen Sie die Definition von qsort() in der entsprechenden
// man-Page nach.
//
// Schreiben Sie ein Programm, das ein int-Array mit 10 Werten
// zwischen 1 und 1000 definiert.
// Verwenden Sie dieses Array:
//    int arr [] ={10,286,888,104,22,399,58,38,1,478,6,99};
//
// Verwenden Sie die Funktion qsort() um das Array zuerst
// aufsteigend und dann absteigend zu sortieren.
// Definieren Sie dazu zwei Vergleichsfunktionen asc() und desc()
// die dem Funktionsprototypen oben entsprechen und jeweils eine
// aufsteigende oder absteigende Sortierreihenfolge implementieren.
// Geben Sie die sortierten Arrays auf stdout aus.
// Ausgabeformat:
// Aufsteigend:
// ...
// Absteigend:
//...
// ----------------------------------------------------------------
// Systemnahe Programmierung 6. Semester
//
// Susanne Peer SWD21


// INFO:
// Gruppe 1: Info das dies nächstes mal angeschaut wird, hierzu seien Sie nicht
// mehr gekommen im Unterricht
