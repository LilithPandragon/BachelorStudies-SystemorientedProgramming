var typed = new Typed('#element', {
  strings: ['ERROR ^1000', '„Keine Panik!“'],
  typeSpeed: 50,
  cursorChar: '\u2586',
});
