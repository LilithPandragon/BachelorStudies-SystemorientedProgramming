#ifndef _WEBBY_H
#define _WEBBY_H

#define HTTP_BUFFER_SIZE 2048
#define WEBBY_ENV_ROOT_DIR "WEBBY_ROOT"

#endif // _WEBBY_H
