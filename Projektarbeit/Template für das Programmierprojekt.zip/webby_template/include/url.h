#ifndef _URL_H
#define _URL_H

char *decodeUri(char *uri);

#endif // _URL_H
