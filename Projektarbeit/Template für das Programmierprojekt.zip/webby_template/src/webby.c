/*
 * webby.c
 * main entry point for webby webserver
 */
#include <stdio.h>
#include <stdlib.h>
#include <webby.h>

int main(int argc, char* argv[]){
  exit(EXIT_SUCCESS);
}
