# webby

Simple webserver for educational purposes
